package com.example.demo.fullstack.DemoFullStack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoFullStackApplicationTests {

	@Test
	void contextLoads() {
	}

}
